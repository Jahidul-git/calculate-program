<?php 
	
	class Student{

		public function details(){
			echo 'Student Class Exists';
		}

	}

 ?>